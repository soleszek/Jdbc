create view studencizrzeszowa as
  select `baza_testowa`.`studenci`.`Imie` AS `imie`, `baza_testowa`.`studenci`.`Nazwisko` AS `nazwisko`
  from `baza_testowa`.`studenci`
  where (`baza_testowa`.`studenci`.`Miasto` = 'Rzeszów');

